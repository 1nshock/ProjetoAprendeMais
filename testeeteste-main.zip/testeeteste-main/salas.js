// dados simulados iniciais
let rooms = [
    { id: 1, nome: "Sala 01", capacidadeAtual: 20, capacidadeMaxima: 40, descricao: "Matemática", senha: "123" },
    { id: 2, nome: "Sala 02", capacidadeAtual: 22, capacidadeMaxima: 40, descricao: "História", senha: "456" },
    { id: 3, nome: "Sala 03", capacidadeAtual: 4, capacidadeMaxima: 40, descricao: "Química", senha: "" },
    { id: 4, nome: "Sala 04", capacidadeAtual: 19, capacidadeMaxima: 40, descricao: "Português", senha: "789" },
];
let nextRoomId = 5;

// Variáveis de Estado
let currentMode = 'view'; 

// Elementos DOM
const roomListScroller = document.getElementById('room-list-scroller');
const roomListView = document.getElementById('room-list-view');
const createEditFormContainer = document.getElementById('create-edit-form');
const sidebarActions = document.querySelector('.sidebar-actions');
const cancelBtnContainer = document.getElementById('cancel-action-btn-container');

// Botões laterais
const createModeBtn = document.getElementById('create-mode-btn');
const editModeBtn = document.getElementById('edit-mode-btn');
const deleteModeBtn = document.getElementById('delete-mode-btn');
const cancelActionBtn = document.getElementById('cancel-action-btn');

// =LÓGICA DE GERENCIAMENTO DE ESTADO 

function setMode(newMode) {
    currentMode = newMode;

    // 1 Controle da visibilidade dos elementos principais
    const isFormMode = (newMode === 'create_form' || newMode === 'edit_form'); 
    const isSelectionMode = (newMode === 'edit' || newMode === 'delete');

    roomListView.classList.toggle('hidden', isFormMode);
    createEditFormContainer.classList.toggle('hidden', !isFormMode);
    
    // 2 Controle da visibilidade dos painéis laterais (botões CRUD vs. CANCELAR)
    sidebarActions.classList.toggle('hidden', isSelectionMode || isFormMode);
    
    // O botão CANCELAR lateral deve aparecer nos modos 'edit' e 'delete'
    cancelBtnContainer.classList.toggle('hidden', newMode !== 'edit' && newMode !== 'delete');

    // 3 Renderiza a lista se for um modo de visualização ou seleção
    if (!isFormMode) {
        renderRooms();
    }
}


//= RENDERIZAÇÃO DA LISTA DE SALAS

function renderRooms() {
    roomListScroller.innerHTML = '';
    
    rooms.forEach(room => {
        const card = document.createElement('div');
        card.className = 'room-card';

        // Elementos de Informação
    const name = document.createElement('span');
    name.className = 'room-card-name';
    name.textContent = room.nome;
    // Adiciona atributo com a descrição para o tooltip
    name.setAttribute('data-tooltip', room.descricao || 'Sem descrição.');

        const capacity = document.createElement('span');
        capacity.className = 'room-card-capacity';
        capacity.textContent = `${room.capacidadeAtual}/${room.capacidadeMaxima}`;

        // Botão de Ação
        // Cria um container de botões para aparecer ao lado da sala
        const actionsContainer = document.createElement('div');
        actionsContainer.className = 'room-actions-container';

        // Botão Entrar (sempre visível no modo view)
        const enterBtn = document.createElement('button');
        enterBtn.className = 'room-action-btn action-enter-btn';
        enterBtn.textContent = 'Entrar';
        enterBtn.onclick = () => alert(`Entrando na sala: ${room.nome}`);

        // Botão Editar (sempre visível ao lado)
        const editBtn = document.createElement('button');
        editBtn.className = 'room-action-btn action-edit-btn';
        editBtn.textContent = 'Editar';
        editBtn.dataset.roomId = room.id;
        editBtn.onclick = () => openFormModal('edit', room);

        // Botão Apagar (sempre visível ao lado) - usa o id do room para excluir
        const delBtn = document.createElement('button');
        delBtn.className = 'room-action-btn action-delete-btn';
        delBtn.textContent = 'Apagar';
        delBtn.dataset.roomId = room.id;
        delBtn.onclick = (e) => {
            // previne propagação caso o card tenha outros handlers
            e.stopPropagation();
            deleteRoom(room.id);
        };

        // Mostrar/ocultar botões conforme o modo atual
        if (currentMode === 'view') {
            // só mostra Entrar e Editar/Apagar como ícones/actions opcionais
            actionsContainer.appendChild(enterBtn);
            actionsContainer.appendChild(editBtn);
            actionsContainer.appendChild(delBtn);
        } else if (currentMode === 'edit') {
            actionsContainer.appendChild(editBtn);
        } else if (currentMode === 'delete') {
            actionsContainer.appendChild(delBtn);
        }

        card.appendChild(name);
        card.appendChild(capacity);
        card.appendChild(actionsContainer);
        roomListScroller.appendChild(card);
    });
}


//  LOGICA DO CRUD SIMULADO 

// 1. ABRIR FORMULARIO (CRIAR ou EDITAR)
function openFormModal(mode, room = null) {
    // Define o modo correto: 'create_form' ou 'edit_form'
    setMode(mode === 'edit' ? 'edit_form' : 'create_form'); 
    
    const isEdit = mode === 'edit';
    const formTitle = isEdit ? 'Editar Salas' : 'Criar Salas';

    const roomName = isEdit ? room.nome : '';
    const roomDesc = isEdit ? room.descricao : '';
    const roomCapacity = isEdit ? room.capacidadeMaxima : '';
    const roomPassword = isEdit ? room.senha : '';
    
    // Atributos de capacidade
    const MAX_CAPACITY = 40;
    const MIN_CAPACITY = 1;
    
    createEditFormContainer.innerHTML = `
        <div class="form-wrapper">
            <div class="form-header">
                <h2>${formTitle}</h2>
                <button type="button" onclick="setMode('view')" class="sidebar-btn danger-action form-cancel-btn">
                    CANCELAR
                </button>
            </div>
            
            <form id="room-crud-form">
                <input type="hidden" id="room-id" value="${isEdit ? room.id : ''}">
                
                <div class="input-group">
                    <label for="room-name">NOME</label>
                    <input type="text" id="room-name" placeholder="Nome" value="${roomName}" required>
                </div>
                
                <div class="input-group">
                    <label for="room-description">DESCRIÇÃO</label>
                    <input type="text" id="room-description" placeholder="Descrição" value="${roomDesc}">
                </div>
                
                <div class="input-group">
                    <label for="room-capacity">CAPACIDADE MÁXIMA</label>
                    <input type="number" id="room-capacity" placeholder="Capacidade Máxima" value="${roomCapacity}" required min="${MIN_CAPACITY}" max="${MAX_CAPACITY}">
                </div>
                
                <div class="input-group">
                    <label for="room-password">SENHA</label>
                    <div class="password-input-wrapper">
                        <input type="password" id="room-password" placeholder="Senha (opcional)" value="${roomPassword}">
                        <button type="button" id="toggle-password-btn" class="password-toggle" aria-label="Mostrar senha">
                            <!-- olho (SVG) -->
                            <svg id="icon-eye" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                </div>
                
                <div class="form-actions form-footer">
                    <button type="submit" class="sidebar-btn primary-action confirm-btn">Confirmar</button>
                    <button type="button" onclick="setMode('view')" class="sidebar-btn danger-action cancel-btn">Cancelar</button>
                </div>
            </form>
        </div>
    `;
    
    document.getElementById('room-crud-form').addEventListener('submit', handleFormSubmit);
    // adiciona comportamento de mostrar/ocultar senha
    const toggleBtn = document.getElementById('toggle-password-btn');
    const pwdInput = document.getElementById('room-password');
    if (toggleBtn && pwdInput) {
        const eyeSvg = {
            open: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            closed: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7 .95-1.67 2.27-3.24 3.82-4.57m3.12-2.22A10.94 10.94 0 0 1 12 5c7 0 11 7 11 7 0 1.28-.28 2.5-.78 3.6M1 1l22 22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
        };

        // start with open icon
        toggleBtn.innerHTML = eyeSvg.open;
        toggleBtn.setAttribute('aria-pressed', 'false');

        toggleBtn.addEventListener('click', () => {
            if (pwdInput.type === 'password') {
                pwdInput.type = 'text';
                toggleBtn.innerHTML = eyeSvg.closed;
                toggleBtn.setAttribute('aria-label', 'Ocultar senha');
                toggleBtn.setAttribute('aria-pressed', 'true');
            } else {
                pwdInput.type = 'password';
                toggleBtn.innerHTML = eyeSvg.open;
                toggleBtn.setAttribute('aria-label', 'Mostrar senha');
                toggleBtn.setAttribute('aria-pressed', 'false');
            }
        });
    }
}

// 2 ENVIAR FORMULÁRIO (CONFIRMAR)
function handleFormSubmit(e) {
    e.preventDefault();

    const id = document.getElementById('room-id').value;
    const nome = document.getElementById('room-name').value;
    const descricao = document.getElementById('room-description').value;
    const capacidadeMaxima = parseInt(document.getElementById('room-capacity').value);
    const senha = document.getElementById('room-password').value;
    
    // vvalidação de limite de capacidade
    const MAX_CAPACITY = 40;
    const MIN_CAPACITY = 1;
    
    if (capacidadeMaxima > MAX_CAPACITY || capacidadeMaxima < MIN_CAPACITY || isNaN(capacidadeMaxima)) {
        alert(`A Capacidade Máxima deve ser um número entre ${MIN_CAPACITY} e ${MAX_CAPACITY}.`);
        return; 
    }

    if (id) {
        // Modo Edição (Update)
        const roomIndex = rooms.findIndex(r => r.id == id);
        if (roomIndex !== -1) {
            rooms[roomIndex] = {
                ...rooms[roomIndex],
                nome,
                descricao,
                capacidadeMaxima,
                senha
            };
        }
    } else {
        // Modo Criação (Create)
        const newRoom = {
            id: nextRoomId++,
            nome,
            descricao,
            capacidadeAtual: 0,
            capacidadeMaxima,
            senha
        };
        rooms.push(newRoom);
    }
    
    alert(`Sala ${id ? 'editada' : 'criada'} com sucesso (Simulação)!`);
    setMode('view'); // Volta para a visualização
}

// 3 APAGAR SALA
function deleteRoom(id) {
    if (confirm("Tem certeza que deseja apagar esta sala?")) {
        rooms = rooms.filter(room => room.id !== id);
        alert("Sala apagada com sucesso (Simulação)!");
        setMode('view');
    }
}


//  EVENT LISTENERS GERAIS 

createModeBtn.addEventListener('click', () => openFormModal('create')); 
editModeBtn.addEventListener('click', () => setMode('edit')); 
deleteModeBtn.addEventListener('click', () => setMode('delete')); 
cancelActionBtn.addEventListener('click', () => setMode('view')); 

// Botão de criar acima da lista (direita)
const createTopBtn = document.getElementById('create-top-btn');
if (createTopBtn) createTopBtn.addEventListener('click', () => openFormModal('create'));

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    setMode('view');
});